<!--/.Navbar -->
<section id="bg2">
    <div class="parallax-overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 offset-lg-5 mt-5  p-4">
                    <div class="inpge-heading mb-3 animate__fadeInRight animate__animated">Our Specifications</div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="mt-5 mb-5">
    <div class="container">
        <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 animate__animated animate__fadeInUp">
                <div class=" box effect6">

                    <h3 class="text-blue text-uppercase"> Special Benefits </h3>
                    <p>For treatment no need to take any leaves & can resume their normal duties. Only checkup is necessary after 15 days.</p>

                    <p>In Rectal prolapsed, Piles, Anal fistula curved by this injection we provide life time guarantee against recurrence.</p>

                    <p>After treatment patient is discharged & needs to come after 15 days for check up.</p>

                </div>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 animate__animated animate__fadeInUp">
                <div class=" box effect6">
                    <h3 class="text-blue text-uppercase"> Existing Method of Treatment</h3>
                    <p>Previously patient suffering from disease like Piles, Anal fistula and Rectal prolapsed were subjected to painful process of thread treatment.</p>

                    <p>Operation & Carbolic Injections :</p>
                    <p>In case of operations, entry in inner rectum also posed a problem. Also there is no guarantee cure.</p>
                    <p>This method had certain limitations. In case of surgical operations blood is necessary.</p>

                    <p>Also people who have diabetic could not be treated by operative procedure. But as our injection is applied in inner rectum area So, Patients with high blood sugar & hypertension problems can also be treated.</p>

                    <p>Bleeding in case of piles can be stopped within half an hour. This cannot be achieved by any other conventional medicines.</p>

                    <p>Our heartfelt desire is to have society which is free from disease like Piles, Anal fistula, rectal prolapsed.</p>
                </div>
            </div>
        </div>
    </div>
</section>