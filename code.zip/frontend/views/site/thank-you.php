<!--/.Navbar -->
<section id="bg2">
<div class="parallax-overlay">
  <div class="container">
    <div class="row">
     <div class="col-lg-7 offset-lg-5 mt-5  p-4">
         <div class="inpge-heading mb-3 animate__fadeInRight animate__animated"> Thank You! </div>
      </div>
    </div>
  </div></div>
</section>

<section>


<div class="jumbotron text-center">
  <h1 class="display-3 text-success">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
  <hr>
  <p>
    Having trouble? <a href="contact.html">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-info btn-sm" href="" role="button">Continue to homepage</a>
  </p>
</div>
</section>