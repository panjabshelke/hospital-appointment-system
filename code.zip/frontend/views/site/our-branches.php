<!--/.Navbar -->
<section id="branch-bg" class="">
    <div class="parallax-overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 offset-lg-5 mt-5  p-4">
                    <div class="inpge-heading mb-3 animate__fadeInRight animate__animated">OUR BRANCHES</div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="   mt-3 mb-3">
    <div class="container">
        <div class="row">

            <div class="col-lg-4 col-md-4 col-xl-4 col-sm-6">
                <div class=" box effect2">
                    <h3>PUNE</h3>
                    <p><i class="fa fa-map-marker"></i> Plot No. P.A.P. / G. /60, Thermax Chowk,<br />
                        Behind Kasturi Market,<br />
                        Majjid Road, Sambhaji Nagar,<br />
                        Chinchwad, Pune - 19.</p>
                    <p><i class="fa fa-phone-square"></i> +91 9112675901 / 7038569384</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-xl-4 col-sm-6">
                <div class=" box effect2">
                    <h3>BRANCH NAME</h3>
                    <p><i class="fa fa-map-marker"></i> Lorem ipsum dolor sit amet,<br />
                        Lorem ipsum dolor sit amet,<br />
                        Lorem ipsum dolor sit amet Road,<br />
                        Lorem ipsum - 40.</p>
                    <p><i class="fa fa-phone-square"></i> +91 0123456789 / +91 0123456789</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-xl-4 col-sm-6">
                <div class=" box effect2">
                    <h3>BRANCH NAME</h3>
                    <p><i class="fa fa-map-marker"></i> Lorem ipsum dolor sit amet,<br />
                        Lorem ipsum dolor sit amet,<br />
                        Lorem ipsum dolor sit amet Road,<br />
                        Lorem ipsum - 44.</p>
                    <p><i class="fa fa-phone-square"></i> +91 0123456789 / +91 0123456789</p>
                </div>
            </div>
        </div>
    </div>
</section>