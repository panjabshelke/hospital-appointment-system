<!--/.Navbar -->
<section id="bg2">
    <div class="parallax-overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 offset-lg-5 mt-5  p-4">
                    <div class="inpge-heading mb-3 animate__fadeInRight animate__animated">ABOUT US</div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>


    <div class="container mt-5">
        <div class="row">

            <div class="col-lg-4 image-style col-md-4 col-sm-6 col-xs-12">

                <img src="<?=Yii::getAlias('@root') . DIRECTORY_SEPARATOR?>img/banner.jpg" alt="about us" class="img-responsive" width="1080" height="auto">
            </div>

            <div class="col-lg-8  image-style col-md-8 col-sm-6 col-xs-12">

                <h2 class="text-uppercase  animate__fadeInLeft animate__animated"> Welcome to, </h2>
                <h3 class="text-blue"> "PILES FREE WORLD" CAMPAIGN THROUGH INOCULATION
                    APPROVED BY GOVT. PATENT. </h3>
                <p class="text-black-20">This Treatment is unique in the medical history of the world, Because No Recurrence
                    after treatment in whole life</p>

            </div>

            <div class="col-lg-12 mt-5 image-style  col-md-12 col-sm-12 box col-xs-12">
                <div class="image-style">
                    <p class="text-black-20">As a result of 40 years of research we ahve with our formally approved injection can cure piles, anal Fistula & Rectal prolapse.
                        In past twenty years we have curved over a lakh of patients by use this treatment.</p>
                    <p> Moreover there has been no relapse of this disease.</p>

                    <p>We offers a life time cure gurantee which is also unique in the medical world.</p>

                    <p>Since this injection is based on Ayurveda it has no adverse side reactions.</p>

                    <p>We have obtained a patent (patent no. 216300) in 2008 not only in india but throughout the world. There is no better or more effective cure for piles, Anal fistula & rectal prolapse.</p>
                </div>
            </div>
        </div>
    </div>
</section>