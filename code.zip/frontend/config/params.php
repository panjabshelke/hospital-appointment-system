<?php
return [
    'adminEmail' => 'panjab@test.in',
    'supportEmail' => 'support@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
    'subject' => 'Contact Us Details',
    'user.passwordResetTokenExpire' => 3600,
];
