<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=hospital-appiontment-system',
            'username' => 'root',
            'password' => 'root',
            'charset' => 'utf8',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            'transport' => [
                       'class' => 'Swift_SmtpTransport',
                       'host' => 'sg2plcpnl0023.prod.sin2.secureserver.net',//mail.pilesfreeworld.com
                       'username' => 'info@pilesfreeworld.com',//info@pilesfreeworld.com
                       'password' => 'q$}PkV=q*y[b',//yskSrxzDuS7pZTX
                       'port' => '465',//587
                       'encryption' => 'ssl',//tls
            ],
            'useFileTransport' => false,
        ],
        // 'mailer' => [
        //     'class' => 'yii\swiftmailer\Mailer',
        //     // send all mails to a file by default. You have to set
        //     // 'useFileTransport' to false and configure a transport
        //     // for the mailer to send real emails.
        //     'viewPath' => '@common/mail',
        //     // 'transport' => [
        //     //            'class' => 'Swift_SmtpTransport',
        //     //            'host' => 'smtp.office365.com',
        //     //            'username' => 'username@test.com',
        //     //            'password' => 'password',
        //     //            'port' => '587',
        //     //            'encryption' => 'tls',
        //     // ],
        //    'useFileTransport' => false,
        // ],
    ],
];
