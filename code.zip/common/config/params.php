<?php
return [
    'adminEmail' => 'admin@example.com',
    // 'supportEmail' => 'support@example.com',
    'supportEmail' => 'info@pilesfreeworld.com',  //'support@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
    'user.passwordResetTokenExpire' => 3600,
    'doctors_id' => 1,
    'branches_id' => 2,
];
