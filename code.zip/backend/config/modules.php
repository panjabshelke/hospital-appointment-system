<?php

return [
    // 'product' => [
    //     'class' => 'backend\modules\product\product',
    // ],
    'gridview' => [
        'class' => 'kartik\grid\Module'
    ],
    'admin' => [
        'class' => 'mdm\admin\Module',
    ],
];
